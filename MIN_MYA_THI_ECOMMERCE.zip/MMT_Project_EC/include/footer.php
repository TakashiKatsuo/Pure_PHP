    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>

    <!-- BEGIN: Footer-->
    <footer class="footer footer-static footer-light navbar-shadow">
        <p class="clearfix blue-grey lighten-2 mb-0"><span class="float-md-left d-block d-md-inline-block mt-25">COPYRIGHT &copy; 2020<a class="text-bold-800 grey darken-2" target="_blank">Baibao,</a>All rights Reserved</span>
            <button class="btn btn-primary btn-icon scroll-top" type="button"><i class="feather icon-arrow-up"></i></button>
        </p>
    </footer>
    <!-- END: Footer-->


    <!-- BEGIN: Vendor JS-->
    <script src="backend/app-assets/vendors/js/vendors.min.js"></script>
    <!-- BEGIN Vendor JS-->

    <!-- BEGIN: Page Vendor JS-->
    <script src="backend/app-assets/vendors/js/ui/jquery.sticky.js"></script>
    <script src="backend/app-assets/vendors/js/ui/prism.min.js"></script>
    <script src="backend/app-assets/vendors/js/extensions/wNumb.js"></script>
    <script src="backend/app-assets/vendors/js/extensions/nouislider.min.js"></script>
    <script src="backend/app-assets/vendors/js/forms/select/select2.full.min.js"></script>
    <script src="backend/app-assets/vendors/js/forms/spinner/jquery.bootstrap-touchspin.js"></script>
    <script src="backend/app-assets/vendors/js/extensions/swiper.min.js"></script>
    <script src="backend/app-assets/vendors/js/extensions/jquery.steps.min.js"></script>
    <script src="backend/app-assets/vendors/js/forms/validation/jquery.validate.min.js"></script>
    <script src="backend/app-assets/vendors/js/extensions/toastr.min.js"></script>
    <!-- END: Page Vendor JS-->

    <!-- BEGIN: Theme JS-->
    <script src="backend/app-assets/js/core/app-menu.js"></script>
    <script src="backend/app-assets/js/core/app.js"></script>
    <script src="backend/app-assets/js/scripts/components.js"></script>
    <!-- END: Theme JS-->

    <!-- BEGIN: Page JS-->
    <script src="backend/app-assets/js/scripts/pages/app-ecommerce-shop.js"></script>
    <script src="backend/app-assets/js/scripts/pages/app-ecommerce-details.js"></script>
    <script src="backend/app-assets/js/scripts/forms/number-input.js"></script>
    <script src="backend/app-assets/js/scripts/pages/invoice.js"></script>
    <!-- END: Page JS-->

    <!-- BEGIN: ADD TO CART JS-->
    <script type="text/javascript" src="js/add_to_cart_script.js"></script>
    <!-- END: ADD TO CART JS-->

</body>
<!-- END: Body-->

</html>