<?php 
    session_start();

    if (isset($_SESSION['user'])) {

    include 'dbconnection/dbconnect.php';
    include 'include/header.php';
?>

    <!-- BEGIN: Content-->
    <div class="app-content content">
        <div class="content-overlay"></div>
        <div class="header-navbar-shadow"></div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-9 col-12 mb-2">
                    <div class="row breadcrumbs-top">
                        <div class="col-12">
                            <h2 class="content-header-title float-left mb-0">Subcategory List</h2>
                            <div class="breadcrumb-wrapper col-12">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item">Dashboard</a>
                                    </li>
                                    <li class="breadcrumb-item active">Subcategory List
                                    </li>
                                </ol>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="content-header-right text-md-right col-md-3 col-12 d-md-block d-none">
                    <div class="form-group breadcrum-right">
                        <a href="subcategory_add_form.php" class="btn btn-round btn-relief-success"><i class="ficon feather icon-plus"></i>Add New</a>
                    </div>
                </div>
            </div>
            <div class="content-body">
                


            </div>
        </div>
    </div>
    <!-- END: Content-->

    <div class="sidenav-overlay"></div>
    <div class="drag-target"></div>


    <!-- Modal -->
    <div id="dataModal" class="modal fade">  
        <div class="modal-dialog">  
            <div class="modal-content">  
                <div class="modal-header">  
                     <h4 class="modal-title">Subcategory Details</h4>  
                </div>  
                <div class="modal-body" id="show_detail">  
                </div>  
                <div class="modal-footer">  
                     <button type="button" class="btn btn-round btn-danger" data-dismiss="modal">Close</button>  
                </div>  
            </div>  
        </div>  
    </div>

<?php 
    include 'include/footer.php';

    } else {

        header("location:auth_login_form.php");
    }
?>


<!-- Script -->
<script>
    $(document).ready(function(){
        $(document).on('click', '.view_data', function(){  
            var Subcategoryid = $(this).attr("id");  
            if(Subcategoryid != ''){  
                $.ajax({  
                    url:"subcategory_detail.php",  
                    method:"POST",  
                    data:{Subcategoryid:Subcategoryid},  
                    success:function(data){  
                        $('#show_detail').html(data);  
                        $('#dataModal').modal('show');  
                    }  
                });  
            }            
        });
    });
</script>